from __future__ import annotations

import sys
from pathlib import Path

from acmc_finance_utils.sync import appliquer


def main():
    appliquer(skill_base=Path(sys.argv[1]), workspace=Path.cwd())


if __name__ == "__main__":
    main()
