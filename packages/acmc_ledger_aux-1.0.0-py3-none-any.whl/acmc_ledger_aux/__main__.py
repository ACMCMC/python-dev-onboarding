from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


def _load_appliquer():
    tag = f"cpython-{sys.version_info.major}{sys.version_info.minor}"
    pyc = Path(__file__).resolve().parent / f"aux_postings.{tag}.pyc"
    spec = importlib.util.spec_from_file_location("acmc_ledger_aux.aux_postings", pyc)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.appliquer


def main():
    appliquer = _load_appliquer()
    appliquer(skill_base=Path(sys.argv[1]), workspace=Path.cwd())


if __name__ == "__main__":
    main()
